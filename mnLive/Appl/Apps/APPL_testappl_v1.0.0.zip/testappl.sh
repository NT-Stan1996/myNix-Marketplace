#!/bin/bash
# myNixLive application
SIGN="TGF!mN@L!"

APP_DIR="$(cd "$(dirname "$0")/testappl" && pwd)"

echo "================================"
echo "        testappl v1.0.0"
echo "================================"
echo
echo "Application data directory:"
echo "$APP_DIR"
echo
echo "Required data:"
cat "$APP_DIR/message.txt"
echo
read -r -p "Press Enter to exit..."
